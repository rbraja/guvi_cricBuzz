import streamlit as st
from services.cricbuzz_api import search_player, get_player_stats

def player_stats_page():
    st.header("👤 Cricket Player Statistics")

    # Player Search
    query = st.text_input("Enter player name", placeholder="e.g., Virat Kohli, MS Dhoni")

    if st.button("🔍 Search"):
        if not query.strip():
            st.warning("Please enter a player name.")
            return

        results = search_player(query)
        if not results or "player" not in results:
            st.error("No players found.")
            return

        st.session_state.players = results["player"]

    # Only proceed if players are in session state
    if "players" in st.session_state:
        players = st.session_state.players

        # If multiple players found
        if len(players) > 1:
            st.subheader("Select Player")
            player_options = [
                f"{p.get('name', 'Unknown')} ({p.get('country', '-')})" for p in players
            ]
            selected_index = st.selectbox("Multiple players found. Please choose:", range(len(players)),
                                          format_func=lambda i: player_options[i])
            player = players[selected_index]
        else:
            player = players[0]

        player_id = str(player.get("id"))
        data = get_player_stats(player_id)

        if not data:
            st.error("No stats available for this player.")
            return

        # Basic Player Info
        st.subheader(f"{data.get('name', 'Unknown Player')}")
        st.write(f"**Full Name:** {data.get('fullName', '-')}")
        st.write(f"**Born:** {data.get('DoB', '-')}")
        st.write(f"**Role:** {data.get('role', '-')}")
        st.write(f"**Batting Style:** {data.get('bat', '-')}")
        st.write(f"**Bowling Style:** {data.get('bowl', '-')}")
