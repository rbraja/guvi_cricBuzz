import streamlit as st
from modules.live_scores import live_scores_page
from modules.player_stats import player_stats_page
from modules.sql_analytics import sql_analytics_page
from modules.crud_ops import crud_ops_page

st.set_page_config(page_title="Cricbuzz Dashboard", layout="wide")

# Sidebar Navigation
st.sidebar.title("🏏 Cricket Dashboard")
page = st.sidebar.radio(
    "Choose a page:",
    ["Live Scores", "Player Stats", "SQL Analytics", "CRUD Operations"]
)

st.title(f"📊 {page}")

if page == "Live Scores":
    live_scores_page()
elif page == "Player Stats":
    player_stats_page()
elif page == "SQL Analytics":
    sql_analytics_page()
elif page == "CRUD Operations":
    crud_ops_page()
