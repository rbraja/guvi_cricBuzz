# services/db.py
import sqlite3
import os

# cricket.db sits in project root (one level up from services/)
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "cricket.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # enable foreign keys
    cursor.execute("PRAGMA foreign_keys = ON;")

    # -------- players --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        playing_role TEXT,
        batting_style TEXT,
        bowling_style TEXT,
        country TEXT,
        dob TEXT
    );
    """)

    # -------- venues --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS venues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        venue_name TEXT NOT NULL,
        city TEXT,
        country TEXT,
        capacity INTEGER
    );
    """)

    # -------- series --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS series (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        series_name TEXT NOT NULL,
        host_country TEXT,
        match_type TEXT,
        start_date DATE,
        total_matches INTEGER
    );
    """)

    # -------- matches --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS matches (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        series_id INTEGER,
        venue_id INTEGER,
        match_description TEXT,
        team1 TEXT,
        team2 TEXT,
        match_date DATE,
        status TEXT,
        winner TEXT,
        victory_margin INTEGER,
        victory_type TEXT, -- 'runs' or 'wickets'
        result TEXT,
        toss_winner TEXT,
        toss_decision TEXT,
        venue_country TEXT,
        FOREIGN KEY(series_id) REFERENCES series(id) ON DELETE SET NULL,
        FOREIGN KEY(venue_id) REFERENCES venues(id) ON DELETE SET NULL
    );
    """)

    # -------- player_stats (aggregated per format) --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS player_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        format TEXT NOT NULL,
        matches INTEGER DEFAULT 0,
        innings INTEGER DEFAULT 0,
        runs INTEGER DEFAULT 0,
        centuries INTEGER DEFAULT 0,
        wickets INTEGER DEFAULT 0,
        batting_average REAL DEFAULT 0.0,
        bowling_average REAL DEFAULT 0.0,
        strike_rate REAL DEFAULT 0.0,
        economy_rate REAL DEFAULT 0.0,
        FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE
    );
    """)

    # -------- partnerships --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS partnerships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        match_id INTEGER,
        innings INTEGER,
        player1_id INTEGER,
        player2_id INTEGER,
        partnership_runs INTEGER,
        batting_position1 INTEGER,
        batting_position2 INTEGER,
        FOREIGN KEY(match_id) REFERENCES matches(id) ON DELETE CASCADE,
        FOREIGN KEY(player1_id) REFERENCES players(id) ON DELETE CASCADE,
        FOREIGN KEY(player2_id) REFERENCES players(id) ON DELETE CASCADE
    );
    """)

    # -------- bowling_stats (per match) --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS bowling_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        match_id INTEGER NOT NULL,
        format TEXT,
        overs_bowled REAL DEFAULT 0.0,
        wickets INTEGER DEFAULT 0,
        runs_conceded INTEGER DEFAULT 0,
        economy_rate REAL DEFAULT 0.0,
        FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE,
        FOREIGN KEY(match_id) REFERENCES matches(id) ON DELETE CASCADE
    );
    """)

    # -------- player_match_stats (per match batting) --------
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS player_match_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        player_id INTEGER NOT NULL,
        match_id INTEGER NOT NULL,
        format TEXT,
        runs INTEGER DEFAULT 0,
        balls_faced INTEGER DEFAULT 0,
        strike_rate REAL DEFAULT 0.0,
        catches INTEGER DEFAULT 0,
        stumpings INTEGER DEFAULT 0,
        team_won INTEGER DEFAULT 0, -- 1 if player's team won that match, else 0
        victory_margin INTEGER DEFAULT 0,
        victory_type TEXT,
        FOREIGN KEY(player_id) REFERENCES players(id) ON DELETE CASCADE,
        FOREIGN KEY(match_id) REFERENCES matches(id) ON DELETE CASCADE
    );
    """)

    conn.commit()
    conn.close()
    # print
    print(" init_db(): cricket.db initialized at", DB_PATH)
