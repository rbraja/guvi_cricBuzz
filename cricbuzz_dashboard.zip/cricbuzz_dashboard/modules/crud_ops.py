# pages/crud_ops.py
import streamlit as st
import pandas as pd
import sqlite3
import datetime
from services.db import init_db, DB_PATH

st.set_page_config(page_title="CRUD Operations", layout="wide")

def get_options(cursor, table, id_col="id", label_expr="name"):
    try:
        cursor.execute(f"SELECT {id_col}, {label_expr} FROM {table}")
        rows = cursor.fetchall()
        return {f"{r[0]} - {r[1]}": r[0] for r in rows}
    except Exception:
        return {}

def crud_ops_page():
    st.header("🛠️ CRUD Operations")
    init_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    operation = st.selectbox("Choose operation", ["Players", "Matches", "Venues", "Series",
                                                  "Player Stats", "Partnerships", "Bowling Stats", "Player Match Stats"])
    st.subheader(f"Selected: {operation}")
    sub_op = st.radio("Action", ["Create", "Read", "Update", "Delete"], index=0)

    # ---------- PLAYERS ----------
    if operation == "Players":
        if sub_op == "Create":
            name = st.text_input("Name")
            playing_role = st.text_input("Playing Role")
            batting_style = st.text_input("Batting Style")
            bowling_style = st.text_input("Bowling Style")
            country = st.text_input("Country")
            dob = st.date_input(
            "Date of Birth",
            min_value=datetime.date(1900, 1, 1),
            max_value=datetime.date.today()
        )
            if st.button("Add Player"):
                cursor.execute("""INSERT INTO players 
                                  (name, playing_role, batting_style, bowling_style, country, dob)
                                  VALUES (?, ?, ?, ?, ?, ?)""", 
                               (name, playing_role, batting_style, bowling_style, country, str(dob)))
                conn.commit()
                st.success(f"Player '{name}' added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("SELECT * FROM players", conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "players", "id", "name")
            if not options:
                st.info("No players to update.")
            else:
                choice = st.selectbox("Select player", list(options.keys()))
                pid = options[choice]
                row = cursor.execute("SELECT * FROM players WHERE id=?", (pid,)).fetchone()

                name = st.text_input("Name", row[1])
                playing_role = st.text_input("Playing Role", row[2] or "")
                batting_style = st.text_input("Batting Style", row[3] or "")
                bowling_style = st.text_input("Bowling Style", row[4] or "")
                country = st.text_input("Country", row[5] or "")

                # Handle DOB safely
                if row[6]:
                    try:
                        dob_value = pd.to_datetime(row[6], errors='coerce').date()
                        if dob_value is None:
                            dob_value = datetime.date.today()
                    except Exception:
                        dob_value = datetime.date.today()
                else:
                    dob_value = datetime.date.today()

                dob = st.date_input(
                "Date of Birth",
                value=dob_value,
                min_value=datetime.date(1900, 1, 1),
                max_value=datetime.date.today()
            )

            if st.button("Update Player"):
                cursor.execute("""
                    UPDATE players
                    SET name=?, playing_role=?, batting_style=?, bowling_style=?, country=?, dob=?
                    WHERE id=?
                """, (name, playing_role, batting_style, bowling_style, country, dob.isoformat(), pid))
                conn.commit()
                st.success("Player updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "players", "id", "name")
            if not options:
                st.info("No players to delete.")
            else:
                choice = st.selectbox("Select player to delete", list(options.keys()))
                pid = options[choice]
                if st.button("Delete Player"):
                    cursor.execute("DELETE FROM players WHERE id=?", (pid,))
                    conn.commit()
                    st.success("Player deleted.")
                    
                    # Match 
    if operation == "Matches":
        # Always initialize options to prevent UnboundLocalError
        series_options = get_options(cursor, "series", "id", "series_name") or {}
        venue_options = get_options(cursor, "venues", "id", "venue_name") or {}
        toss_decision_options = {"None": None, "Bat": "bat", "Bowl": "bowl", "Opt to bat": "bat", "Opt to bowl": "bowl"}

        if sub_op == "Create":
            match_description = st.text_input("Match Description")
            team1 = st.text_input("Team 1")
            team2 = st.text_input("Team 2")
            match_date = st.date_input("Match Date")

            series_choice = st.selectbox("Series", ["None"] + list(series_options.keys()))
            series_id = series_options.get(series_choice) if series_choice != "None" else None

            venue_choice = st.selectbox("Venue", ["None"] + list(venue_options.keys()))
            venue_id = venue_options.get(venue_choice) if venue_choice != "None" else None

            status = st.text_input("Status")
            winner = st.text_input("Winner")
            victory_margin = st.number_input("Victory Margin", min_value=0)
            victory_type = st.selectbox("Victory Type", ["None", "runs", "wickets"])
            result = st.text_input("Result")
            toss_winner = st.text_input("Toss Winner")
            toss_decision_label = st.selectbox("Toss Decision", list(toss_decision_options.keys()))
            toss_decision = toss_decision_options[toss_decision_label]
            venue_country = st.text_input("Venue Country")

            if st.button("Add Match"):
                cursor.execute("""INSERT INTO matches (
                                    series_id, venue_id, match_description, team1, team2, match_date,
                                    status, winner, victory_margin, victory_type, result,
                                    toss_winner, toss_decision, venue_country
                                  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                               (series_id, venue_id, match_description, team1, team2, str(match_date),
                                status, winner, victory_margin,
                                victory_type if victory_type != "None" else None,
                                result, toss_winner, toss_decision, venue_country))
                conn.commit()
                st.success("Match added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("""
                SELECT m.id, s.series_name, v.venue_name, m.match_description, m.team1, m.team2,
                       m.match_date, m.status, m.winner, m.victory_margin, m.victory_type,
                       m.result, m.toss_winner, m.toss_decision, m.venue_country
                FROM matches m
                LEFT JOIN series s ON m.series_id = s.id
                LEFT JOIN venues v ON m.venue_id = v.id
                ORDER BY m.match_date DESC
            """, conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "matches", "id", "match_description") or {}
            if not options:
                st.info("No matches to update.")
            else:
                choice = st.selectbox("Select Match", list(options.keys()))
                mid = options[choice]
                row = cursor.execute("SELECT * FROM matches WHERE id=?", (mid,)).fetchone()

                # Reverse mapping for default selection
                series_reverse = {v: k for k, v in series_options.items()}
                venue_reverse = {v: k for k, v in venue_options.items()}

                selected_series = series_reverse.get(row[1], "None")
                selected_venue = venue_reverse.get(row[2], "None")

                series_choice = st.selectbox("Series", ["None"] + list(series_options.keys()),
                                             index=(["None"] + list(series_options.keys())).index(selected_series))
                series_id = series_options.get(series_choice) if series_choice != "None" else None

                venue_choice = st.selectbox("Venue", ["None"] + list(venue_options.keys()),
                                            index=(["None"] + list(venue_options.keys())).index(selected_venue))
                venue_id = venue_options.get(venue_choice) if venue_choice != "None" else None

                match_description = st.text_input("Match Description", row[3])
                team1 = st.text_input("Team 1", row[4])
                team2 = st.text_input("Team 2", row[5])
                match_date = st.date_input("Match Date", pd.to_datetime(row[6]) if row[6] else datetime.date.today())
                status = st.text_input("Status", row[7] or "")
                winner = st.text_input("Winner", row[8] or "")
                victory_margin = st.number_input("Victory Margin", value=row[9] or 0)
                victory_type_list = ["None", "runs", "wickets"]
                victory_type = st.selectbox("Victory Type", victory_type_list,
                                            index=victory_type_list.index(row[10]) if row[10] in victory_type_list else 0)
                result = st.text_input("Result", row[11] or "")
                toss_winner = st.text_input("Toss Winner", row[12] or "")
                td_reverse = {v: k for k, v in toss_decision_options.items()}
                selected_td_label = td_reverse.get(row[13], "None")
                toss_decision_label = st.selectbox("Toss Decision", list(toss_decision_options.keys()),
                                                   index=list(toss_decision_options.keys()).index(selected_td_label))
                toss_decision = toss_decision_options[toss_decision_label]
                venue_country = st.text_input("Venue Country", row[14] or "")

                if st.button("Update Match"):
                    cursor.execute("""UPDATE matches SET
                                        series_id=?, venue_id=?, match_description=?, team1=?, team2=?,
                                        match_date=?, status=?, winner=?, victory_margin=?, victory_type=?,
                                        result=?, toss_winner=?, toss_decision=?, venue_country=?
                                      WHERE id=?""",
                                   (series_id, venue_id, match_description, team1, team2, str(match_date),
                                    status, winner, victory_margin,
                                    victory_type if victory_type != "None" else None,
                                    result, toss_winner, toss_decision, venue_country, mid))
                    conn.commit()
                    st.success("Match updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "matches", "id", "match_description") or {}
            if not options:
                st.info("No matches to delete.")
            else:
                choice = st.selectbox("Select Match to Delete", list(options.keys()))
                mid = options[choice]
                if st.button("Delete Match"):
                    cursor.execute("DELETE FROM matches WHERE id=?", (mid,))
                    conn.commit()
                    st.success("Match deleted.")

    # ---------- VENUES ----------
    elif operation == "Venues":
        if sub_op == "Create":
            venue_name = st.text_input("Venue Name")
            city = st.text_input("City")
            country = st.text_input("Country")
            capacity = st.number_input("Capacity", min_value=0)
            if st.button("Add Venue"):
                cursor.execute("INSERT INTO venues (venue_name, city, country, capacity) VALUES (?, ?, ?, ?)",
                               (venue_name, city, country, capacity))
                conn.commit()
                st.success("Venue added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("SELECT * FROM venues", conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "venues", "id", "venue_name") or {}
            if not options:
                st.info("No venues to update.")
            else:
                choice = st.selectbox("Select Venue", list(options.keys()))
                vid = options[choice]
                row = cursor.execute("SELECT * FROM venues WHERE id=?", (vid,)).fetchone()
                venue_name = st.text_input("Venue Name", row[1])
                city = st.text_input("City", row[2] or "")
                country = st.text_input("Country", row[3] or "")
                capacity = st.number_input("Capacity", min_value=0, value=row[4] or 0)
                if st.button("Update Venue"):
                    cursor.execute("UPDATE venues SET venue_name=?, city=?, country=?, capacity=? WHERE id=?",
                                   (venue_name, city, country, capacity, vid))
                    conn.commit()
                    st.success("Venue updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "venues", "id", "venue_name") or {}
            if not options:
                st.info("No venues to delete.")
            else:
                choice = st.selectbox("Select Venue to Delete", list(options.keys()))
                vid = options[choice]
                if st.button("Delete Venue"):
                    cursor.execute("DELETE FROM venues WHERE id=?", (vid,))
                    conn.commit()
                    st.success("Venue deleted.")


    # ---------- SERIES ----------
    elif operation == "Series":
        if sub_op == "Create":
            series_name = st.text_input("Series Name")
            host_country = st.text_input("Host Country")
            match_type = st.text_input("Match Type")
            start_date = st.date_input("Start Date")
            total_matches = st.number_input("Total Matches", min_value=0)
            if st.button("Add Series"):
                cursor.execute("""INSERT INTO series (series_name, host_country, match_type, start_date, total_matches)
                                  VALUES (?, ?, ?, ?, ?)""",
                               (series_name, host_country, match_type, str(start_date), total_matches))
                conn.commit()
                st.success("Series added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("SELECT * FROM series", conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "series", "id", "series_name")
            if not options:
                st.info("No series to update.")
            else:
                choice = st.selectbox("Select series", list(options.keys()))
                sid = options[choice]
                row = cursor.execute("SELECT * FROM series WHERE id=?", (sid,)).fetchone()
                series_name = st.text_input("Series Name", row[1])
                host_country = st.text_input("Host Country", row[2] or "")
                match_type = st.text_input("Match Type", row[3] or "")
                start_date = st.text_input("Start Date", row[4] or "")
                total_matches = st.number_input("Total Matches", min_value=0, value=(row[5] or 0))
                if st.button("Update Series"):
                    cursor.execute("UPDATE series SET series_name=?, host_country=?, match_type=?, start_date=?, total_matches=? WHERE id=?",
                                   (series_name, host_country, match_type, start_date, total_matches, sid))
                    conn.commit()
                    st.success("Series updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "series", "id", "series_name")
            if not options:
                st.info("No series to delete.")
            else:
                choice = st.selectbox("Select series to delete", list(options.keys()))
                sid = options[choice]
                if st.button("Delete Series"):
                    cursor.execute("DELETE FROM series WHERE id=?", (sid,))
                    conn.commit()
                    st.success("Series deleted.")

    # ---------- PLAYER STATS ----------
    elif operation == "Player Stats":
        if sub_op == "Create":
            players = get_options(cursor, "players", "id", "name")
            if not players:
                st.warning("Add players first.")
            else:
                p_choice = st.selectbox("Select player", list(players.keys()))
                player_id = players[p_choice]
                fmt = st.selectbox("Format", ["Test", "ODI", "T20I"])
                matches = st.number_input("Matches", min_value=0)
                innings = st.number_input("Innings", min_value=0)
                runs = st.number_input("Runs", min_value=0)
                centuries = st.number_input("Centuries", min_value=0)
                wickets = st.number_input("Wickets", min_value=0)
                batting_avg = st.number_input("Batting Average", value=0.0)
                bowling_avg = st.number_input("Bowling Average", value=0.0)
                strike_rate = st.number_input("Strike Rate", value=0.0)
                economy = st.number_input("Economy Rate", value=0.0)
                if st.button("Add Player Stat"):
                    cursor.execute("""INSERT INTO player_stats (player_id, format, matches, innings, runs, centuries, wickets, batting_average, bowling_average, strike_rate, economy_rate)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                                   (player_id, fmt, matches, innings, runs, centuries, wickets, batting_avg, bowling_avg, strike_rate, economy))
                    conn.commit()
                    st.success("Player stat added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("""
                SELECT ps.id, p.name AS player_name, ps.format, ps.matches, ps.innings, ps.runs, ps.centuries, ps.wickets, ps.batting_average, ps.bowling_average, ps.strike_rate
                FROM player_stats ps
                LEFT JOIN players p ON ps.player_id = p.id
                ORDER BY ps.id DESC
            """, conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "player_stats", "id", "format")
            if not options:
                st.info("No player stats to update.")
            else:
                choice = st.selectbox("Select stat", list(options.keys()))
                sid = options[choice]
                row = cursor.execute("SELECT * FROM player_stats WHERE id=?", (sid,)).fetchone()
                # row columns: id, player_id, format, matches, innings, runs, centuries, wickets, batting_average, bowling_average, strike_rate, economy_rate
                players = get_options(cursor, "players", "id", "name")
                p_choice = st.selectbox("Player", list(players.keys()), index=list(players.values()).index(row[1]) if row[1] in list(players.values()) else 0)
                player_id = players[p_choice]
                fmt = st.text_input("Format", row[2])
                matches = st.number_input("Matches", min_value=0, value=(row[3] or 0))
                innings = st.number_input("Innings", min_value=0, value=(row[4] or 0))
                runs = st.number_input("Runs", min_value=0, value=(row[5] or 0))
                centuries = st.number_input("Centuries", min_value=0, value=(row[6] or 0))
                wickets = st.number_input("Wickets", min_value=0, value=(row[7] or 0))
                batting_avg = st.number_input("Batting Average", value=(row[8] or 0.0))
                bowling_avg = st.number_input("Bowling Average", value=(row[9] or 0.0))
                strike_rate = st.number_input("Strike Rate", value=(row[10] or 0.0))
                economy = st.number_input("Economy Rate", value=(row[11] or 0.0))
                if st.button("Update Player Stat"):
                    cursor.execute("""UPDATE player_stats SET player_id=?, format=?, matches=?, innings=?, runs=?, centuries=?, wickets=?, batting_average=?, bowling_average=?, strike_rate=?, economy_rate=? WHERE id=?""",
                                   (player_id, fmt, matches, innings, runs, centuries, wickets, batting_avg, bowling_avg, strike_rate, economy, sid))
                    conn.commit()
                    st.success("Player stat updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "player_stats", "id", "format")
            if not options:
                st.info("No player stats to delete.")
            else:
                choice = st.selectbox("Select player stat to delete", list(options.keys()))
                sid = options[choice]
                if st.button("Delete Player Stat"):
                    cursor.execute("DELETE FROM player_stats WHERE id=?", (sid,))
                    conn.commit()
                    st.success("Player stat deleted.")

    # ---------- PARTNERSHIPS ----------
    elif operation == "Partnerships":
        if sub_op == "Create":
            players = get_options(cursor, "players", "id", "name")
            if not players:
                st.warning("Add players first.")
            else:
                p1 = st.selectbox("Player 1", list(players.keys()))
                p2 = st.selectbox("Player 2", list(players.keys()))
                match_opts = get_options(cursor, "matches", "id", "match_description")
                match_choice = st.selectbox("Match", ["None"] + list(match_opts.keys()))
                match_id = match_opts[match_choice] if match_choice != "None" and match_choice in match_opts else None
                innings = st.number_input("Innings", min_value=1)
                runs = st.number_input("Partnership Runs", min_value=0)
                if st.button("Add Partnership"):
                    cursor.execute("INSERT INTO partnerships (match_id, innings, player1_id, player2_id, partnership_runs) VALUES (?, ?, ?, ?, ?)",
                                   (match_id, innings, players[p1], players[p2], runs))
                    conn.commit()
                    st.success("Partnership added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("""
                SELECT pt.id, m.match_description, p1.name AS player1, p2.name AS player2, pt.innings, pt.partnership_runs
                FROM partnerships pt
                LEFT JOIN matches m ON pt.match_id = m.id
                LEFT JOIN players p1 ON pt.player1_id = p1.id
                LEFT JOIN players p2 ON pt.player2_id = p2.id
            """, conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "partnerships", "id", "partnership_runs")
            if not options:
                st.info("No partnerships to update.")
            else:
                choice = st.selectbox("Select partnership", list(options.keys()))
                pid = options[choice]
                row = cursor.execute("SELECT * FROM partnerships WHERE id=?", (pid,)).fetchone()
                new_runs = st.number_input("Runs", min_value=0, value=(row[5] or 0))
                if st.button("Update Partnership"):
                    cursor.execute("UPDATE partnerships SET partnership_runs=? WHERE id=?", (new_runs, pid))
                    conn.commit()
                    st.success("Partnership updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "partnerships", "id", "partnership_runs")
            if not options:
                st.info("No partnerships to delete.")
            else:
                choice = st.selectbox("Select partnership to delete", list(options.keys()))
                pid = options[choice]
                if st.button("Delete Partnership"):
                    cursor.execute("DELETE FROM partnerships WHERE id=?", (pid,))
                    conn.commit()
                    st.success("Partnership deleted.")

    # ---------- BOWLING STATS ----------
    elif operation == "Bowling Stats":
        if sub_op == "Create":
            players = get_options(cursor, "players", "id", "name")
            matches = get_options(cursor, "matches", "id", "match_description")
            if not players:
                st.warning("Add players first.")
            else:
                p_choice = st.selectbox("Player", list(players.keys()))
                m_choice = st.selectbox("Match", ["None"] + list(matches.keys()))
                player_id = players[p_choice]
                match_id = matches[m_choice] if m_choice != "None" and m_choice in matches else None
                fmt = st.selectbox("Format", ["Test", "ODI", "T20I"])
                overs = st.number_input("Overs Bowled", min_value=0.0)
                wickets = st.number_input("Wickets", min_value=0)
                runs_conceded = st.number_input("Runs Conceded", min_value=0)
                economy = st.number_input("Economy Rate", value=(runs_conceded/(overs or 1)) if overs else 0.0)
                if st.button("Add Bowling Stat"):
                    cursor.execute("""INSERT INTO bowling_stats (player_id, match_id, format, overs_bowled, wickets, runs_conceded, economy_rate)
                                      VALUES (?, ?, ?, ?, ?, ?, ?)""",
                                   (player_id, match_id, fmt, overs, wickets, runs_conceded, economy))
                    conn.commit()
                    st.success("Bowling stat added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("""
                SELECT b.id, p.name AS player_name, m.match_description, b.format, b.overs_bowled, b.wickets, b.runs_conceded, b.economy_rate
                FROM bowling_stats b
                LEFT JOIN players p ON b.player_id = p.id
                LEFT JOIN matches m ON b.match_id = m.id
            """, conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "bowling_stats", "id", "format")
            if not options:
                st.info("No bowling stats to update.")
            else:
                choice = st.selectbox("Select bowling stat", list(options.keys()))
                bid = options[choice]
                row = cursor.execute("SELECT * FROM bowling_stats WHERE id=?", (bid,)).fetchone()
                overs = st.number_input("Overs Bowled", min_value=0.0, value=(row[4] or 0.0))
                wickets = st.number_input("Wickets", min_value=0, value=(row[5] or 0))
                runs_conceded = st.number_input("Runs Conceded", min_value=0, value=(row[6] or 0))
                economy = st.number_input("Economy Rate", value=(row[7] or 0.0))
                if st.button("Update Bowling Stat"):
                    cursor.execute("UPDATE bowling_stats SET overs_bowled=?, wickets=?, runs_conceded=?, economy_rate=? WHERE id=?",
                                   (overs, wickets, runs_conceded, economy, bid))
                    conn.commit()
                    st.success("Bowling stat updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "bowling_stats", "id", "format")
            if not options:
                st.info("No bowling stats to delete.")
            else:
                choice = st.selectbox("Select bowling stat to delete", list(options.keys()))
                bid = options[choice]
                if st.button("Delete Bowling Stat"):
                    cursor.execute("DELETE FROM bowling_stats WHERE id=?", (bid,))
                    conn.commit()
                    st.success("Bowling stat deleted.")

    # ---------- PLAYER MATCH STATS ----------
    elif operation == "Player Match Stats":
        if sub_op == "Create":
            players = get_options(cursor, "players", "id", "name")
            matches = get_options(cursor, "matches", "id", "match_description")
            if not players:
                st.warning("Add players first.")
            else:
                p_choice = st.selectbox("Player", list(players.keys()))
                m_choice = st.selectbox("Match", ["None"] + list(matches.keys()))
                player_id = players[p_choice]
                match_id = matches[m_choice] if m_choice != "None" and m_choice in matches else None
                fmt = st.selectbox("Format", ["Test", "ODI", "T20I"])
                runs = st.number_input("Runs", min_value=0)
                balls = st.number_input("Balls Faced", min_value=0)
                sr = st.number_input("Strike Rate", value=(runs/(balls or 1))*100 if balls else 0.0)
                catches = st.number_input("Catches", min_value=0)
                stumpings = st.number_input("Stumpings", min_value=0)
                team_won = st.checkbox("Player's team won this match?")
                if st.button("Add Player Match Stat"):
                    cursor.execute("""INSERT INTO player_match_stats (player_id, match_id, format, runs, balls_faced, strike_rate, catches, stumpings, team_won)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                                   (player_id, match_id, fmt, runs, balls, sr, catches, stumpings, 1 if team_won else 0))
                    conn.commit()
                    st.success("Player match stat added.")

        elif sub_op == "Read":
            df = pd.read_sql_query("""
                SELECT pms.id, pl.name AS player_name, m.match_description, pms.format, pms.runs, pms.balls_faced, pms.strike_rate, pms.catches, pms.stumpings, pms.team_won
                FROM player_match_stats pms
                LEFT JOIN players pl ON pms.player_id = pl.id
                LEFT JOIN matches m ON pms.match_id = m.id
            """, conn)
            st.dataframe(df)

        elif sub_op == "Update":
            options = get_options(cursor, "player_match_stats", "id", "runs")
            if not options:
                st.info("No player match stats to update.")
            else:
                choice = st.selectbox("Select PMS", list(options.keys()))
                sid = options[choice]
                row = cursor.execute("SELECT * FROM player_match_stats WHERE id=?", (sid,)).fetchone()
                runs = st.number_input("Runs", min_value=0, value=(row[4] or 0))
                balls = st.number_input("Balls Faced", min_value=0, value=(row[5] or 0))
                sr = st.number_input("Strike Rate", value=(row[6] or 0.0))
                catches = st.number_input("Catches", min_value=0, value=(row[7] or 0))
                stumpings = st.number_input("Stumpings", min_value=0, value=(row[8] or 0))
                team_won = st.checkbox("Team won?", value=bool(row[9]))
                if st.button("Update PMS"):
                    cursor.execute("UPDATE player_match_stats SET runs=?, balls_faced=?, strike_rate=?, catches=?, stumpings=?, team_won=? WHERE id=?",
                                   (runs, balls, sr, catches, stumpings, 1 if team_won else 0, sid))
                    conn.commit()
                    st.success("Player match stat updated.")

        elif sub_op == "Delete":
            options = get_options(cursor, "player_match_stats", "id", "runs")
            if not options:
                st.info("No player match stats to delete.")
            else:
                choice = st.selectbox("Select PMS to delete", list(options.keys()))
                sid = options[choice]
                if st.button("Delete PMS"):
                    cursor.execute("DELETE FROM player_match_stats WHERE id=?", (sid,))
                    conn.commit()
                    st.success("Player match stat deleted.")

    conn.close()

if __name__ == "__main__":
    crud_ops_page()
