import requests
import streamlit as st

API_HOST = "cricbuzz-cricket.p.rapidapi.com"
API_KEY = "152bcfd36emsha19dfa4f48b23cep11ef7fjsn9a1c936da812"
#API_KEY = "c69b4667a9mshb9e0051cfd530cdp1a9078jsn0c8259969ba8"
#API_KEY = "7e13c7a81cmsh6ddf915d321feebp181197jsn89c5c86accb1"

HEADERS = {
    "x-rapidapi-host": API_HOST,
    "x-rapidapi-key": API_KEY
}

BASE_URL = f"https://{API_HOST}"


def fetch_api(endpoint: str):
    url = f"{BASE_URL}{endpoint}"
    try:
        res = requests.get(url, headers=HEADERS, timeout=10)
        res.raise_for_status()
        return res.json()
    except requests.RequestException as e:
        st.error(f"API Error ({endpoint}): {e}")
        return None



def get_live_matches():
    return fetch_api("/matches/v1/live") or {}


def get_match_info(match_id: str):
    return fetch_api(f"/mcenter/v1/{match_id}") or {}


def get_scorecard(match_id: str):
    return fetch_api(f"/mcenter/v1/{match_id}/scard") or {}


def get_player_stats(player_id: str):
    return fetch_api(f"/stats/v1/player/{player_id}") or {}

def search_player(query: str):
    return fetch_api(f"/stats/v1/player/search?plrN={query}") or {}