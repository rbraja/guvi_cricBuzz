import streamlit as st
from services.cricbuzz_api import get_live_matches, get_scorecard
import datetime

# Convert milliseconds to  datetime
def format_timestamp(ms):
    if not ms:
        return None
    try:
        return datetime.datetime.fromtimestamp(int(ms) / 1000).strftime("%d %b %Y, %I:%M %p")
    except Exception:
        return str(ms) 

def live_scores_page():
    st.header("🏏 Live Scores")

    #  Fetch live matches
    matches = get_live_matches()
    if not matches or "typeMatches" not in matches:
        st.warning("No live matches found.")
        return

    # Collect all matches
    all_matches = []
    for t in matches.get("typeMatches", []):
        for m in t.get("seriesMatches", []):
            series_wrapper = m.get("seriesAdWrapper")
            if series_wrapper and "matches" in series_wrapper:
                all_matches.extend(series_wrapper["matches"])

    if not all_matches:
        st.warning("No matches available right now.")
        return

    # Dropdown to select match
    match_names = [
        f"{m['matchInfo']['team1']['teamName']} vs {m['matchInfo']['team2']['teamName']}"
        for m in all_matches
    ]
    selected = st.selectbox("Select a Match", match_names)

    selected_match = next(
        m for m in all_matches
        if f"{m['matchInfo']['team1']['teamName']} vs {m['matchInfo']['team2']['teamName']}" == selected
    )

    match_id = selected_match["matchInfo"]["matchId"]

    #  Fetch scorecard
    scorecard_data = get_scorecard(match_id) or {}

    # Extract team names
    team1 = selected_match["matchInfo"]["team1"]["teamName"]
    team2 = selected_match["matchInfo"]["team2"]["teamName"]

    # Tabs
    tab_overview, tab_score, tab_batting, tab_bowling, tab_debug = st.tabs(
        ["📋 Overview", "📊 Scorecard", "🏏 Batting", "🎯 Bowling", "🐞 Debug"]
    )

    # ============ TAB 1: OVERVIEW ============
    with tab_overview:
        venue = selected_match.get("matchInfo", {}).get("venueInfo", {}).get("ground", "Unknown Venue")
        match_format = selected_match.get("matchInfo", {}).get("matchFormat", "Unknown Format")
        match_state = selected_match.get("matchInfo", {}).get("state", "Unknown")
        series = selected_match.get("matchInfo", {}).get("seriesName", "Unknown Series")
        toss_status = selected_match.get("matchInfo", {}).get("tossResults", {}).get("tossWinnerName")
        toss_decision = selected_match.get("matchInfo", {}).get("tossResults", {}).get("decision")

        st.subheader(f"{team1} vs {team2}")
        st.markdown(f"**Series:** {series}")
        st.markdown(f"**Venue:** {venue}")
        st.markdown(f"**Format:** {match_format}")
        st.markdown(f"**Match State:** {match_state}")
        if toss_status:
            st.markdown(f"**Toss:** {toss_status} won the toss and chose to {toss_decision}")

        #  Show formatted dates
        start_date = selected_match.get("matchInfo", {}).get("startDate")
        end_date = selected_match.get("matchInfo", {}).get("endDate")
        if start_date and end_date:
            st.markdown(f"**Dates:** {format_timestamp(start_date)} ➝ {format_timestamp(end_date)}")

        city = selected_match.get("matchInfo", {}).get("venueInfo", {}).get("city")
        if city:
            st.markdown(f"**City:** {city}")

        match_desc = selected_match.get("matchInfo", {}).get("matchDesc")
        if match_desc:
            st.markdown(f"**Match Desc:** {match_desc}")
        
       # Show Match Result / Winner if available
    match_result = selected_match.get("matchInfo", {}).get("status")
    if match_result:
        st.markdown(f"**Match Result:** {match_result}")
    # ============ TAB 2: SCORECARD ============
    with tab_score:
        if "scorecard" in scorecard_data:
            for innings_index, innings in enumerate(scorecard_data["scorecard"]):
                st.markdown(f"### {innings.get('batteamname', 'Unknown')} Innings")
                
                # Score
                score = innings.get("score", 0)
                wickets = innings.get("wickets", 0)
                overs = innings.get("overs", 0)
                run_rate = innings.get("runrate", 0.0)
                st.metric("Score", f"{score}/{wickets}", f"{overs} overs, RR: {run_rate}")


                # Top Batsman
                batsmen = innings.get("batsman", [])
                if batsmen:
                    top_batsman = max(batsmen, key=lambda x: x.get("runs", 0))
                    st.markdown(f"**Top Scorer:** {top_batsman.get('name')} - {top_batsman.get('runs')} runs")

                # Top Bowler
                bowlers = innings.get("bowler", [])
                if bowlers:
                    top_bowler = max(bowlers, key=lambda x: x.get("wickets", 0))
                    st.markdown(f"**Best Bowler:** {top_bowler.get('name')} - {top_bowler.get('wickets')} wickets")

                # Recent deliveries
                recent_balls = scorecard_data.get("recentBalls", [])
                if recent_balls:
                    st.markdown("**Recent Deliveries:**")
                    st.write(" ".join(recent_balls[-5:]))
        else:
            st.warning("⚠️ Scorecard not available yet.")

    # ============ TAB 3: BATTING ============
    with tab_batting:
        if "scorecard" in scorecard_data:
            for innings in scorecard_data["scorecard"]:
                st.markdown(f"### 🏏 {innings.get('batteamname', 'Unknown')} Batting")
                batsmen = innings.get("batsman", [])
                if batsmen:
                    st.table([
                        {
                            "Batsman": b.get("name"),
                            "Runs": b.get("runs"),
                            "Balls": b.get("balls"),
                            "4s": b.get("fours"),
                            "6s": b.get("sixes"),
                            "SR": b.get("strkrate"),
                            "Out": b.get("outdec")
                        } for b in batsmen
                    ])
                else:
                    st.info("No batting data yet.")
        else:
            st.info("Batting details are not available yet.")

    # ============ TAB 4: BOWLING ============
    with tab_bowling:
        if "scorecard" in scorecard_data:
            for innings in scorecard_data["scorecard"]:
                st.markdown(f"### 🎯 {innings.get('batteamname', 'Unknown')} Bowling")
                bowlers = innings.get("bowler", [])
                if bowlers:
                    st.table([
                        {
                            "Bowler": b.get("name"),
                            "Overs": b.get("overs"),
                            "Runs": b.get("runs"),
                            "Wickets": b.get("wickets"),
                            "Econ": b.get("economy")
                        } for b in bowlers
                    ])
                else:
                    st.info("No bowling data yet.")
        else:
            st.info("Bowling details are not available yet.")

    # ============ TAB 5: DEBUG ============
    with tab_debug:
        st.write("Raw API Response for debugging 👇")
        st.json(scorecard_data)
