# pages/sql_analytics.py
import streamlit as st
import pandas as pd
import sqlite3
from services.db import init_db, DB_PATH

st.set_page_config(page_title="SQL Analytics", layout="wide")

def sql_analytics_page():
    st.header("📊 Cricket SQL Analytics")

    # ensure DB exists & tables
    init_db()
    conn = sqlite3.connect(DB_PATH)

    st.subheader("Select analysis question")
    queries = {
        "1. Find all players who represent India": """
            SELECT name, playing_role, batting_style, bowling_style
            FROM players
            WHERE country = 'India';
        """,

        "2. Matches played in last few days (7 days)": """
            SELECT match_description, team1, team2, v.venue_name, v.city, match_date
            FROM matches m
            LEFT JOIN venues v ON m.venue_id = v.id
            WHERE DATE(match_date) >= DATE('now', '-7 day')
            ORDER BY match_date DESC;
        """,

        "3. Top 10 highest run scorers in ODI cricket": """
            SELECT p.name, ps.runs AS total_runs, ps.batting_average, ps.centuries
            FROM player_stats ps
            JOIN players p ON ps.player_id = p.id
            WHERE ps.format = 'ODI'
            ORDER BY ps.runs DESC
            LIMIT 10;
        """,

        "4. Venues capacity > 30000": """
            SELECT venue_name, city, country, capacity
            FROM venues
            WHERE capacity > 30000
            ORDER BY capacity DESC;
        """,

        "5. Number of matches won by each team": """
            SELECT winner AS team_name, COUNT(*) AS wins
            FROM matches
            WHERE winner IS NOT NULL AND winner != ''
            GROUP BY winner
            ORDER BY wins DESC;
        """,

        "6. Count players by playing role": """
            SELECT playing_role, COUNT(*) AS player_count
            FROM players
            GROUP BY playing_role;
        """,

        "7. Highest individual batting score by format": """
            -- use player_match_stats: highest 'runs' by format
            SELECT format, MAX(runs) AS highest_score
            FROM player_match_stats
            GROUP BY format;
        """,

        "8. Cricket series started in 2024": """
            SELECT series_name, host_country, match_type, start_date, total_matches
            FROM series
            WHERE strftime('%Y', start_date) = '2024';
        """,

        # Intermediate
        "9. All-rounders >1000 runs AND >50 wickets (per format)": """
            SELECT p.name, ps.format, ps.runs AS total_runs, ps.wickets AS total_wickets
            FROM player_stats ps
            JOIN players p ON ps.player_id = p.id
            WHERE ps.runs > 1000 AND ps.wickets > 50
            ORDER BY ps.runs DESC;
        """,

        "10. Last 20 completed matches": """
            SELECT match_description, team1, team2, winner, victory_margin, victory_type, v.venue_name
            FROM matches m
            LEFT JOIN venues v ON m.venue_id = v.id
            WHERE result = 'completed' OR status = 'completed'
            ORDER BY match_date DESC
            LIMIT 20;
        """,

        "11. Compare players across formats (players with >=2 formats)": """
            SELECT p.name,
                   SUM(CASE WHEN ps.format='Test' THEN ps.runs ELSE 0 END) AS test_runs,
                   SUM(CASE WHEN ps.format='ODI' THEN ps.runs ELSE 0 END) AS odi_runs,
                   SUM(CASE WHEN ps.format='T20I' THEN ps.runs ELSE 0 END) AS t20_runs,
                   ROUND(AVG(ps.batting_average), 2) AS overall_batting_avg,
                   COUNT(DISTINCT ps.format) AS formats_played
            FROM player_stats ps
            JOIN players p ON ps.player_id = p.id
            GROUP BY p.id
            HAVING formats_played >= 2;
        """,

        "12. Team performance home vs away": """
            SELECT winner AS team_name,
                   SUM(CASE WHEN m.venue_country = winner THEN 1 ELSE 0 END) AS home_wins,
                   SUM(CASE WHEN m.venue_country != winner THEN 1 ELSE 0 END) AS away_wins
            FROM matches m
            WHERE winner IS NOT NULL
            GROUP BY winner;
        """,

        "13. 100+ run partnerships by consecutive batsmen": """
            SELECT p1.name AS player1, p2.name AS player2, SUM(partnership_runs) AS total_runs, innings
            FROM partnerships pt
            JOIN players p1 ON pt.player1_id = p1.id
            JOIN players p2 ON pt.player2_id = p2.id
            WHERE ABS(batting_position1 - batting_position2) = 1
            GROUP BY pt.player1_id, pt.player2_id, innings
            HAVING total_runs >= 100;
        """,

        "14. Bowling performance by venue": """
        SELECT 
    b.player_id, 
    pl.name AS bowler_name, 
    v.venue_name,
    COUNT(DISTINCT b.match_id) AS matches_played,
    SUM(b.wickets) AS total_wickets,
    ROUND(AVG(b.economy_rate), 2) AS avg_economy
FROM bowling_stats b
JOIN matches m ON b.match_id = m.id
JOIN venues v ON m.venue_id = v.id
JOIN players pl ON b.player_id = pl.id
GROUP BY b.player_id, v.id, pl.name, v.venue_name
ORDER BY total_wickets DESC
LIMIT 20;


        """,

        "15. Player performance in close matches": """
            SELECT pl.name,
                   ROUND(AVG(pms.runs),2) AS avg_runs,
                   COUNT(*) AS close_matches_played,
                   SUM(CASE WHEN pms.team_won = 1 THEN 1 ELSE 0 END) AS wins_in_close_matches
            FROM player_match_stats pms
            JOIN players pl ON pms.player_id = pl.id
            JOIN matches m ON pms.match_id = m.id
            WHERE (m.victory_type = 'runs' AND m.victory_margin < 50)
               OR (m.victory_type = 'wickets' AND m.victory_margin < 5)
            GROUP BY pl.id;
        """,

        "16. Player yearly batting performance (since 2020)": """
            SELECT p.name, strftime('%Y', m.match_date) AS year,
                   ROUND(AVG(pms.runs),2) AS avg_runs_per_match,
                   ROUND(AVG(pms.strike_rate),2) AS avg_strike_rate,
                   COUNT(DISTINCT m.id) AS matches
            FROM player_match_stats pms
            JOIN matches m ON pms.match_id = m.id
            JOIN players p ON pms.player_id = p.id
            WHERE m.match_date >= '2020-01-01'
            GROUP BY p.id, year
            HAVING matches >= 5;
        """,

        # Advanced
        "17. Toss win advantage analysis": """
            SELECT toss_decision,
                   ROUND(SUM(CASE WHEN toss_winner = winner THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS win_pct
            FROM matches
            WHERE toss_winner IS NOT NULL AND winner IS NOT NULL
            GROUP BY toss_decision;
        """,

        "18. Most economical bowlers in limited-overs": """
            SELECT pl.name, ROUND(SUM(b.runs_conceded) * 1.0 / SUM(b.overs_bowled), 2) AS economy_rate,
                   SUM(b.wickets) AS total_wickets, COUNT(DISTINCT b.match_id) AS matches_played
            FROM bowling_stats b
            JOIN players pl ON b.player_id = pl.id
            WHERE b.format IN ('ODI', 'T20I')
            GROUP BY b.player_id
            HAVING matches_played >= 10 AND SUM(b.overs_bowled)*1.0 / matches_played >= 2
            ORDER BY economy_rate ASC;
        """,

        "19. Most consistent batsmen since 2022": """
            -- stddev approximation using variance function: SQLite doesn't have STDDEV by default;
            -- We'll compute sample stddev via (avg(x*x) - avg(x)^2)^0.5
            WITH runs_per_player AS (
                SELECT player_id, pms.runs
                FROM player_match_stats pms
                JOIN matches m ON pms.match_id = m.id
                WHERE m.match_date >= '2022-01-01' AND pms.balls_faced >= 10
            )
            SELECT pl.name,
                   ROUND(AVG(runs),2) AS avg_runs,
                   ROUND(SQRT(AVG(runs*runs) - AVG(runs)*AVG(runs)),2) AS run_stddev,
                   COUNT(*) AS innings
            FROM runs_per_player rp
            JOIN players pl ON rp.player_id = pl.id
            GROUP BY rp.player_id
            HAVING innings >= 5
            ORDER BY run_stddev ASC;
        """,

        "20. Match count and batting averages by format": """
            SELECT p.name,
                   SUM(CASE WHEN ps.format = 'Test' THEN ps.matches ELSE 0 END) AS test_matches,
                   ROUND(AVG(CASE WHEN ps.format = 'Test' THEN ps.batting_average ELSE NULL END),2) AS test_avg,
                   SUM(CASE WHEN ps.format = 'ODI' THEN ps.matches ELSE 0 END) AS odi_matches,
                   ROUND(AVG(CASE WHEN ps.format = 'ODI' THEN ps.batting_average ELSE NULL END),2) AS odi_avg,
                   SUM(CASE WHEN ps.format = 'T20I' THEN ps.matches ELSE 0 END) AS t20_matches,
                   ROUND(AVG(CASE WHEN ps.format = 'T20I' THEN ps.batting_average ELSE NULL END),2) AS t20_avg
            FROM player_stats ps
            JOIN players p ON ps.player_id = p.id
            GROUP BY p.id
            HAVING (test_matches + odi_matches + t20_matches) >= 20;
        """,

        "21. Performance ranking system (top by format)": """
            SELECT p.name, ps.format,
                   ROUND((ps.runs * 0.01) + (ps.batting_average * 0.5) + (ps.strike_rate * 0.3), 2) AS batting_points,
                   ROUND((ps.wickets * 2) + ((50 - ps.bowling_average) * 0.5) + ((6 - ps.economy_rate) * 2), 2) AS bowling_points,
                   ROUND(((ps.runs * 0.01) + (ps.batting_average * 0.5) + (ps.strike_rate * 0.3)) +
                         ((ps.wickets * 2) + ((50 - ps.bowling_average) * 0.5) + ((6 - ps.economy_rate) * 2)), 2) AS total_score
            FROM player_stats ps
            JOIN players p ON ps.player_id = p.id
            ORDER BY ps.format, total_score DESC;
        """,

        "22. Head-to-head match prediction analysis (pairs last 3 years, >=5 matches)": """
            SELECT m1.team1 AS team_a, m1.team2 AS team_b,
                   COUNT(*) AS total_matches,
                   SUM(CASE WHEN m1.winner = m1.team1 THEN 1 ELSE 0 END) AS team1_wins,
                   SUM(CASE WHEN m1.winner = m1.team2 THEN 1 ELSE 0 END) AS team2_wins,
                   ROUND(AVG(CASE WHEN m1.winner = m1.team1 THEN m1.victory_margin ELSE NULL END),1) AS team1_avg_margin,
                   ROUND(AVG(CASE WHEN m1.winner = m1.team2 THEN m1.victory_margin ELSE NULL END),1) AS team2_avg_margin
            FROM matches m1
            WHERE m1.match_date >= DATE('now', '-3 years')
            GROUP BY m1.team1, m1.team2
            HAVING total_matches >= 5;
        """,

        "23. Recent player form classification (last 10 batting performances)": """
            WITH last_n AS (
                SELECT pms.*, pl.name,
                       ROW_NUMBER() OVER (PARTITION BY player_id ORDER BY (SELECT m.match_date FROM matches m WHERE m.id = pms.match_id) DESC) rn
                FROM player_match_stats pms
                JOIN players pl ON pms.player_id = pl.id
            ),
            last10 AS (
                SELECT * FROM last_n WHERE rn <= 10
            ),
            stats AS (
                SELECT player_id, name,
                       AVG(runs) AS avg_last10,
                       AVG(CASE WHEN rn <=5 THEN runs END) AS avg_last5,
                       SUM(CASE WHEN runs >=50 THEN 1 ELSE 0 END) AS fifties_last10,
                       COUNT(*) AS cnt
                FROM last10
                GROUP BY player_id
            )
            SELECT name, avg_last5, avg_last10, fifties_last10,
                   ROUND((avg_last5 - avg_last10),2) AS recent_trend,
                   CASE
                     WHEN avg_last5 >= 50 THEN 'Excellent Form'
                     WHEN avg_last5 >= 30 THEN 'Good Form'
                     WHEN avg_last5 >= 15 THEN 'Average Form'
                     ELSE 'Poor Form'
                   END AS form_label
            FROM stats WHERE cnt >= 5;
        """,

        "24. Best batting partnerships (pairs >=5 partnerships)": """
            SELECT p1.name AS player1, p2.name AS player2,
                   COUNT(*) AS partnerships,
                   AVG(partnership_runs) AS avg_runs,
                   SUM(CASE WHEN partnership_runs > 50 THEN 1 ELSE 0 END) AS over50_count,
                   MAX(partnership_runs) AS highest_partnership,
                   ROUND(SUM(CASE WHEN partnership_runs > 50 THEN 1 ELSE 0 END)*100.0/COUNT(*),1) AS success_rate_pct
            FROM partnerships pt
            JOIN players p1 ON pt.player1_id = p1.id
            JOIN players p2 ON pt.player2_id = p2.id
            WHERE ABS(pt.batting_position1 - pt.batting_position2) = 1
            GROUP BY pt.player1_id, pt.player2_id
            HAVING COUNT(*) >= 5
            ORDER BY avg_runs DESC;
        """,

        "25. Time-series analysis of player performance (quarterly)": """
            WITH pm AS (
                SELECT pms.player_id, pms.runs,
                       DATE(m.match_date) AS match_date,
                       (strftime('%Y', m.match_date) || '-Q' || ((cast(strftime('%m', m.match_date) as integer)-1)/3 + 1)) AS quarter
                FROM player_match_stats pms
                JOIN matches m ON pms.match_id = m.id
            ),
            q AS (
                SELECT player_id, quarter,
                       AVG(runs) AS avg_runs,
                       COUNT(*) AS matches_in_quarter
                FROM pm
                GROUP BY player_id, quarter
            ),
            q2 AS (
                SELECT player_id, quarter, avg_runs,
                       LAG(avg_runs) OVER (PARTITION BY player_id ORDER BY quarter) AS prev_avg
                FROM q
            )
            SELECT p.name, q2.quarter, q2.avg_runs, q2.prev_avg,
                   CASE
                       WHEN q2.prev_avg IS NULL THEN 'N/A'
                       WHEN q2.avg_runs > q2.prev_avg * 1.05 THEN 'Improving'
                       WHEN q2.avg_runs < q2.prev_avg * 0.95 THEN 'Declining'
                       ELSE 'Stable'
                   END AS trend
            FROM q2
            JOIN players p ON q2.player_id = p.id
            ORDER BY p.name, q2.quarter;
        """
    }

    q_titles = list(queries.keys())
    sel = st.selectbox("Choose a question", q_titles)

    query = queries[sel]
    st.markdown("#### SQL Query")
    with st.expander("View SQL"):
        st.code(query, language="sql")

    if st.button("Execute Query"):
        try:
            df = pd.read_sql_query(query, conn)
            st.success(f"Returned {len(df)} rows")
            st.dataframe(df)
        except Exception as e:
            st.error(f"Query failed: {e}")

    conn.close()

if __name__ == "__main__":
    sql_analytics_page()
